#include<iostream>
using namespace std;

bool PrimeOrNot(int n)
{
 for(int i=2;i<n;i++)
    {
        if(n%i==0)
        {return false;}
    }
    return true;
}

int main()
{
    int i,n;
    cin>>n;
    if(n==1)
    {
        cout<<"Neither Prime nor Composite"; exit(0);
    }
   cout<<PrimeOrNot(n);
   
}
